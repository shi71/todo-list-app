import React from 'react';
import App from './App';

function Footer(props) {
    return (
        <>
            <footer>
                <h2>© 2023 SAIT RM:NK201 Continuing Education Class</h2>
            </footer>

        </>
    );
}

export default Footer;